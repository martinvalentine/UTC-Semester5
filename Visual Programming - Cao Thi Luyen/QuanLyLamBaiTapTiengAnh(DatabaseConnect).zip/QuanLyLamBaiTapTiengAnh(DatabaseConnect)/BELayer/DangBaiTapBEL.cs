﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BELayer
{
    public class DangBaiTapBEL
    {
        public string _dangbaitap;

        public string dangbaitap
        {
            get { return _dangbaitap; }
            set { _dangbaitap = value; }
        }

        public string _tenbai;

        public string tenbai
        {
            get { return _tenbai; }
            set { _tenbai = value; }
        }

        public string _mabai;

        public string mabai
        {
            get { return _mabai; }
            set { _mabai = value; }
        }
    }
}
