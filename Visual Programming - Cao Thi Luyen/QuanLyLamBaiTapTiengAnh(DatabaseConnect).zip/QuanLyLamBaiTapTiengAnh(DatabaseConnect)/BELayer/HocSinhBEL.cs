﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BELayer
{
    public class HocSinhBEL
    {
        public string _hoten;

        public string hoten
        {
            get { return _hoten; }
            set { _hoten = value; }
        }

        public string _mahs;

        public string mahs
        {
            get { return _mahs; }
            set { _mahs = value; }
        }


        public string _lop;

        public string lop
        {
            get { return _lop; }
            set { _lop = value; }
        }

    }
}
